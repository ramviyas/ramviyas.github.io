<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'bhuvanap_wordpress');

/** MySQL database username */
define('DB_USER', 'bhuvanap_newsite');

/** MySQL database password */
define('DB_PASSWORD', 'BhrL?dRFHy}L');

/** MySQL hostname */
define('DB_HOST', 'gator3299.hostgator.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '{!k ^k;{AG=rdvSDK:N?e7I8+$)_hPE$UNTUK}w60rxMJ,xpitfaD)CvYc@,jU.F');
define('SECURE_AUTH_KEY',  '$:|#8}7r0r9Y#z[rfsVnNf,2g7k}%W7GTZ>rr|GO-N]St]b0AoM+:=H_%2fsBIB^');
define('LOGGED_IN_KEY',    '?F[%?L>zF:qE^Wa=U|wwtfS8ld1&wn/3&-=^7%MqC}oy*E9(H/{Ylprh|TXFX^Ig');
define('NONCE_KEY',        ';r G7]a1_Np(s$n`aHOLWYKvj$c^<M)PthB(`{jj-Ki$5]X:,vF]OggW`}Dxwr%`');
define('AUTH_SALT',        'b.aE3BDuA`bZQNnN.6@pV:q&M>b[2!O)V<(9k3E5V9qYo`&7%&b266|a>5ozw9t;');
define('SECURE_AUTH_SALT', '3hQmaQgW,d/U::R9g]nC@PPX{A;C%bPjzkusIQ+E&)D<QN >n.mv>h};_c2:_up6');
define('LOGGED_IN_SALT',   'OF+j{y^=xL[;,y{Jj-Na{AvsqM|+P}.uEk4:.(g&(*=N5r$jPTe+(##Xn}cZ<H7s');
define('NONCE_SALT',       '=;xLo ouSV{@$alv.|wjYhucS;2]ZrdHQ3e.N5e,(fv1F*eF]@`{o9P8>V6Y`}sp');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
